<?php
namespace App\Controller;

use Cake\Controller\Controller;
use Cake\Event\Event;
use Cake\Mailer\Email;

class ContactsController extends AppController
{

    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
		$this->loadComponent('Paginator');
    }
	
	public $paginate = [
        'limit' => 10,
		'order'	=> [
			'id' => 'desc'
		]
    ];
	
	public function index()
    {
		$contacts = $this->paginate('Contacts');
        $this->set([
            'contacts' => $this->paginate($this->Contacts),
            '_serialize' => ['contacts']
        ]);
    }
    
    public function add()
    {
		$contact = $this->Contacts->newEntity();
        if($this->request->is('post')) {
			
            $contact= $this->Contacts->patchEntity($contact,$this->request->data);
			$errorsArr = array();
			if ($contact->errors()) {
				foreach($contact->errors() as $key => $error) {
					$errorMsg = array_values($error);
					$errorsArr[$key] = $errorMsg[0]; 
				}
			}
            if ($this->Contacts->save($contact)) {
				$email = new Email('default');
				$email->from(['s@example.com' => 'My Site'])
					->to($this->request->data['email'])
					->subject('Contact Us')
					->send("Dear ".$this->request->data['name'].",\r\n \r\nThank you for contacting us! :) \r\nYour message : '".$this->request->data['message']."' would be forwarded to the concerned person \r\n \r\nRegards,\r\nOur Team");

                $message = 'Saved';
				//$this->Flash->success('Your request has been accepted, our concerned employee will soon contact you!');
            } else {
				$this->Flash->success('Some error occured! :(');
                $message = 'Error';
            }
            $this->set([
                'message' 	=> $message,
                'contact' 	=> $contact,
				'errorsArr'	=> $errorsArr,
            ]);
        }
    }
}
