<?php
namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class ContactsTable extends Table
{
	public function initialize(array $config)
    {
        $this->addBehavior('Timestamp');
    }
	
    public function validationDefault(Validator $validator)
    {
        $validator = new Validator();
        // add the provider to the validator
        $validator->requirePresence('name')
		->notEmpty('name', 'Please fill this field')
		->add('name', [
			'length' => [
				'rule' => ['minLength', 3],
				'message' => 'Name need to be at least 3 characters long',
			]
		])->requirePresence('email')
		->notEmpty('email', 'Please fill this field')
		->add('email',[
			'email' => [
				'rule' 		=> ['email'],
				'message'	=> 'Invalid Email'
			] 
		])->requirePresence('message')
		->notEmpty('message', 'Please fill this field');

        return $validator;
    }
}